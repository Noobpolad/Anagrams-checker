package my_first_time;
import java.util.Arrays;

public class My_first_time {
    
    static boolean check_if_anagram(String first,String second){
        first = first.toLowerCase();
        second = second.toLowerCase();
        first = first.replaceAll("[., ]", "");
        second = second.replaceAll("[., ]", "");
        String[] f = first.split("");
        String[] s = second.split("");
        Arrays.sort(f);
        Arrays.sort(s);
        return Arrays.toString(f).equals(Arrays.toString(s));
    }
    
    public static void main(String[] args) {
        
        System.out.println(check_if_anagram("Moon starer","Astronomer"));
 
    }    
}